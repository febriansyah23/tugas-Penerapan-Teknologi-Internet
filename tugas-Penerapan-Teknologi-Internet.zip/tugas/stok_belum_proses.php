<?php
session_start();
include 'config.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];
$nama = $_SESSION['nama'];

// Mengambil data dari t_stock dengan status UNPROCESSED
$stokBelumProsesQuery = "SELECT * FROM t_stock WHERE status = 'UNPROCESSED'";
$stokBelumProsesResult = $conn->query($stokBelumProsesQuery);

$conn->close(); // Tutup koneksi database
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Stok Belum Diproses</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: #fff;
            min-height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            display: block;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .header {
            margin-left: 250px;
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
        }
        .table {
            background-color: #fff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            width: 100%; /* Memastikan tabel memenuhi lebar kontainer */
        }
        .table th, .table td {
            border-color: #dee2e6;
            text-align: center;
            vertical-align: middle; /* Menyejajarkan konten secara vertikal */
        }
        /* Atur lebar kolom */
        .table th:nth-child(1), .table td:nth-child(1) {
            width: 10%; /* Lebar kolom ID */
        }
        .table th:nth-child(2), .table td:nth-child(2) {
            width: 30%; /* Lebar kolom Nama Produk */
        }
        .table th:nth-child(3), .table td:nth-child(3) {
            width: 40%; /* Lebar kolom Deskripsi */
        }
        .table th:nth-child(4), .table td:nth-child(4) {
            width: 20%; /* Lebar kolom Kode Stok */
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h3 class="text-center">UJUNG BERUNG</h3>
        <div class="text-center mb-4">
            <img src="https://via.placeholder.com/50" class="rounded-circle" alt="User Image">
            <p class="mt-2">User: <?php echo htmlspecialchars($username); ?></p>
            <span class="badge badge-success">Online</span>
        </div>
        <a href="menu_utama.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="produk.php"><i class="fas fa-box-open"></i> Produk</a>
    </div>

    <!-- Header -->
    <div class="header">
        <h5 class="mb-0">Data Stok Belum Diproses</h5>
    </div>

    <div class="content">
        <div class="container">
            <h5 class="mt-4">Data Stok Belum Diproses</h5>
            <hr> <!-- Garis horizontal di bawah judul -->
            <table class="table table-striped table-hover mt-2">
                <thead>
                    <tr>
                        <th>ID stock</th>
                        <th>KD stock</th>
                        <th>Warna 1</th>
                        <th>Warna 2</th>
                        <th>Warna 3</th>
                        <th>Jumlah Warna1</th>
                        <th>Jumlah Warna2</th>
                        <th>Jumlah Warna3</th>
                        <th>Total pesanan</th>
                        <th>Total jadi</th>
                        <th>KD Model</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th>KD produksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($stokBelumProsesResult->num_rows > 0) {
                        while ($row = $stokBelumProsesResult->fetch_assoc()) {
                            echo "<tr>
                                <td>" . htmlspecialchars($row['id_stock']) . "</td>
                                <td>" . htmlspecialchars($row['kd_stock']) . "</td>
                                <td>" . htmlspecialchars($row['warna1']) . "</td>
                                <td>" . htmlspecialchars($row['warna2']) . "</td>
                                <td>" . htmlspecialchars($row['warna3']) . "</td>
                                <td>" . htmlspecialchars($row['jml_w1']) . "</td>
                                <td>" . htmlspecialchars($row['jml_w2']) . "</td>
                                <td>" . htmlspecialchars($row['jml_w3']) . "</td>
                                <td>" . htmlspecialchars($row['total_pesanan']) . "</td>
                                <td>" . htmlspecialchars($row['total_jadi']) . "</td>
                                <td>" . htmlspecialchars($row['kd_model']) . "</td>
                                <td>" . htmlspecialchars($row['status']) . "</td>
                                <td>" . htmlspecialchars($row['tanggal']) . "</td>
                                <td>" . htmlspecialchars($row['kd_produksi']) . "</td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>Tidak ada data.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <a href="menu_utama.php" class="btn btn-primary">Kembali</a>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>