<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk cek username dan password
    $sql = "SELECT * FROM user WHERE user_username = ? AND user_password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['username'] = $user['user_username'];
        $_SESSION['nama'] = $user['user_nama']; // Simpan nama untuk digunakan di dashboard
        header("Location: menu_utama.php");
        exit();
    } else {
        $error = "Nama pengguna atau kata sandi salah.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<style>
    body { background-color: #f5f5f5; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
    .login-container { width: 100%; max-width: 400px; padding: 2rem; background-color: #ffffff; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); border-radius: 8px; text-align: center; }
</style>
</head>
<body>
<div class="login-container">
    <h1 class="mb-4">PT. Ujung Berung</h1>
    <form action="login.php" method="post">
        <div class="form-group">
            <input type="text" name="username" class="form-control" placeholder="Nama Pengguna" required>
        </div>
        <div class="form-group">
            <input type="password" name="password" class="form-control" placeholder="Kata Sandi" required>
        </div>
        <?php if (!empty($error)) echo "<p class='text-danger'>$error</p>"; ?>
        <button type="submit" class="btn btn-primary btn-block">Masuk</button>
    </form>
</div>
</body>
</html>
