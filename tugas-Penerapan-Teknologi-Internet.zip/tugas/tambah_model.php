<?php
// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ujungberung_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Proses simpan data jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kd_model = $_POST['kd_model'];
    $nama_model = $_POST['nama_model'];
    $deskripsi = $_POST['deskripsi'];
    $kd_stock_last = $_POST['kd_stock_last'];

    // Query untuk menyimpan data ke tabel t_model
    $sql = "INSERT INTO t_model (kd_model, nama_model, deskripsi, kd_stock_last) VALUES ('$kd_model', '$nama_model', '$deskripsi', '$kd_stock_last')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Data berhasil disimpan!'); window.location.href='produk.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Model</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: #fff;
            min-height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            display: block;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .header {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            margin-left: 250px;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3 class="text-center">UJUNG BERUNG</h3>
        <div class="text-center mb-4">
            <img src="https://via.placeholder.com/50" class="rounded-circle" alt="User Image">
            <p class="mt-2">User: admin_kantor</p>
            <span class="badge badge-success">Online</span>
        </div>
        <a href="menu_utama.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="produk.php" class="active"><i class="fas fa-box-open"></i> Produk</a>
    </div>

    <!-- Header -->
    <div class="header">
        <div class="d-flex justify-content-between">
            <h5>Tambah Model Baru</h5>
            <p class="mb-0">Eko Budi Setiawan</p>
        </div>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h2>Form Tambah Model</h2>
        <form method="POST" action="">
            <div class="form-group">
                <label for="kd_model">Kode Model</label>
                <input type="text" class="form-control" id="kd_model" name="kd_model" required>
            </div>
            <div class="form-group">
                <label for="nama_model">Nama Model</label>
                <input type="text" class="form-control" id="nama_model" name="nama_model" required>
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <textarea class="form-control" id="deskripsi" name="deskripsi" required></textarea>
            </div>
            <div class="form-group">
                <label for="kd_stock_last">Kode Stock Terakhir</label>
                <input type="text" class="form-control" id="kd_stock_last" name="kd_stock_last" required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="produk.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>