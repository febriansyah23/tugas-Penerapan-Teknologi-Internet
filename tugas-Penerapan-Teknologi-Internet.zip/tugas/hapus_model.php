<?php
session_start();
include 'config.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['kd_model'])) {
    $kd_model = $_GET['kd_model'];

    // Menghapus data dari tabel
    $deleteSql = "DELETE FROM t_model WHERE kd_model = ?";
    $stmt = $conn->prepare($deleteSql);
    $stmt->bind_param("s", $kd_model);
    
    if ($stmt->execute()) {
        // Redirect ke halaman produk setelah berhasil dihapus
        header("Location: produk.php?message=Data berhasil dihapus.");
    } else {
        // Redirect dengan pesan error
        header("Location: produk.php?message=Terjadi kesalahan saat menghapus data.");
    }

    $stmt->close();
} else {
    // Redirect jika tidak ada kode model
    header("Location: produk.php");
}

$conn->close();
?>