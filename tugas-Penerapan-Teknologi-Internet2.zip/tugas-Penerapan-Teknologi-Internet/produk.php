<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ujungberung_db";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}


$sql = "SELECT kd_model, nama_model, deskripsi FROM t_model";
$result = $conn->query($sql);


$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk</title>

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: #fff;
            min-height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            display: block;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .header {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            margin-left: 250px;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
        }
        .table {
            background-color: #fff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        .table th, .table td {
            border-color: #dee2e6;
        }
    </style>
    <script>
        function exportToExcel() {
            let table = document.getElementById("productsTable");
            let rows = Array.from(table.rows);
            let csvContent = rows.map(row => Array.from(row.cells).map(cell => cell.innerText).join(",")).join("\n");
            let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            let url = URL.createObjectURL(blob);
            let a = document.createElement("a");
            a.setAttribute("href", url);
            a.setAttribute("download", "produk.csv");
            a.style.display = "none";
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        }

        function searchModel() {
            let input = document.getElementById("searchInput").value.toLowerCase();
            let table = document.getElementById("productsTable");
            let rows = table.getElementsByTagName("tr");

            for (let i = 1; i < rows.length; i++) { 
                let cells = rows[i].getElementsByTagName("td");
                let found = false;

                if (cells.length > 0) {
                    let cellValue = cells[1].innerText.toLowerCase();
                    if (cellValue.indexOf(input) > -1) {
                        found = true;
                    }
                }
                rows[i].style.display = found ? "" : "none"; 
            }
        }
    </script>
</head>
<body>

    <div class="sidebar">
        <h3 class="text-center">UJUNG BERUNG</h3>
        <div class="text-center mb-4">
            <img src="https://via.placeholder.com/50" class="rounded-circle" alt="User Image">
            <p class="mt-2">User: <?php echo htmlspecialchars($_SESSION['username']); ?></p>
            <span class="badge badge-success">Online</span>
        </div>
        <a href="menu_utama.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="produk.php" class="active"><i class="fas fa-box-open"></i> Produk</a>
    </div>

 
    <div class="header">
        <div class="d-flex justify-content-between">
            <h5>Daftar Produk</h5>
            <p class="mb-0"><?php echo htmlspecialchars($_SESSION['nama']); ?></p>
        </div>
    </div>


    <div class="content">
        <div class="d-flex justify-content-between mb-3">
            <button class="btn btn-primary" onclick="window.location.href='tambah_model.php'">Tambah Model Baru</button>
            <input type="text" id="searchInput" placeholder="Masukkan Kode Model" class="form-control w-50" onkeyup="searchModel()" />
        </div>
        <table id="productsTable" class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Kode Model</th>
                    <th>Nama Model</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    $i = 1;
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $i . "</td>";
                        echo "<td>" . htmlspecialchars($row["kd_model"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["nama_model"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["deskripsi"]) . "</td>";
                        echo "<td>
                                <a href='edit_model.php?kd_model=" . urlencode($row["kd_model"]) . "' class='btn btn-sm btn-primary' title='Edit'><i class='fas fa-edit'></i></a>
                                <a href='hapus_model.php?kd_model=" . urlencode($row["kd_model"]) . "' class='btn btn-sm btn-danger' title='Hapus' onclick='return confirm(\"Apakah Anda yakin ingin menghapus data ini?\");'><i class='fas fa-trash'></i></a>
                            </td>";
                        echo "</tr>";
                        $i++;
                    }
                } else {
                    echo "<tr><td colspan='5'>Tidak ada data produk.</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <button onclick="exportToExcel()" class="btn btn-success mt-3">Export to Excel</button> 
    </div>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>