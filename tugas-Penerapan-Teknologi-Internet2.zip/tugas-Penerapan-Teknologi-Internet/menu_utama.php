<?php
session_start();
include 'config.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];
$nama = $_SESSION['nama'];

$totalProdukQuery = "SELECT COUNT(*) AS total_produk FROM t_model";
$totalProdukResult = $conn->query($totalProdukQuery);
$totalProduk = $totalProdukResult ? $totalProdukResult->fetch_assoc()['total_produk'] : 0;

$totalStokQuery = "SELECT SUM(kd_stock_last) AS total_stok FROM t_model";
$totalStokResult = $conn->query($totalStokQuery);
$totalStok = $totalStokResult ? $totalStokResult->fetch_assoc()['total_stok'] : 0;

$stokDalamProsesQuery = "SELECT COUNT(*) AS stok_dalam_proses FROM t_stock WHERE status = 'IN PROCESS'";
$stokDalamProsesResult = $conn->query($stokDalamProsesQuery);
$stokDalamProses = $stokDalamProsesResult ? $stokDalamProsesResult->fetch_assoc()['stok_dalam_proses'] : 0;

$stokBelumProsesQuery = "SELECT COUNT(*) AS stok_belum_proses FROM t_stock WHERE status = 'UNPROCESSED'";
$stokBelumProsesResult = $conn->query($stokBelumProsesQuery);
$stokBelumProses = $stokBelumProsesResult ? $stokBelumProsesResult->fetch_assoc()['stok_belum_proses'] : 0;

$conn->close(); 
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: #fff;
            min-height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            display: block;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .header {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            margin-left: 250px;
        }

        .content {
            margin-left: 250px;
            padding: 20px;
        }

        .card {
            color: #fff;
            position: relative;
            overflow: hidden;
            padding: 15px;
        }

        .icon {
            font-size: 7rem;
            opacity: 0.2;
            position: absolute;
            right: 10px;
            bottom: 10px;
        }

        .card h5 {
            font-size: 2rem;
        }

        .card p {
            font-size: 1.2rem;
        }

        .card-blue { background-color: #007bff; }
        .card-green { background-color: #28a745; }
        .card-red { background-color: #dc3545; }
        .card-yellow { background-color: #ffc107; }

        .btn-custom {
            position: relative;
            top: 36px; 
            width: 100%;
        }

        .btn-dark-blue { background-color: #0056b3; color: #fff; }
        .btn-dark-green { background-color: #218838; color: #fff; }
        .btn-dark-red { background-color: #c82333; color: #fff; }
        .btn-dark-yellow { background-color: #e0a800; color: #fff; }

        .contact-text {
            color: #000; 
        }
    </style>
</head>
<body>

   
    <div class="sidebar">
        <h3 class="text-center">UJUNG BERUNG</h3>
        <div class="text-center mb-4">
            <img src="https://via.placeholder.com/50" class="rounded-circle" alt="User Image">
            <p class="mt-2">User: <?php echo htmlspecialchars($username); ?></p>
            <span class="badge badge-success">Online</span>
        </div>
        <a href="menu_utama.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="produk.php"><i class="fas fa-box-open"></i> Produk</a>
    </div>

    
    <div class="header">
        <div class="d-flex justify-content-between">
            <h5>Dashboard</h5>
            <div>
                <span><?php echo htmlspecialchars($nama); ?></span>
                <a href="logout.php" class="btn btn-danger btn-sm ml-2">Logout</a>
            </div>
        </div>
    </div>

   
    <div class="content">
        <div class="row">
            <div class="col-md-3">
                <div class="card card-blue text-center mb-4">
                    <div class="card-body">
                        <h5><?php echo htmlspecialchars($totalProduk); ?></h5>
                        <p>Total Produk</p>
                        <a href="produk.php" class="btn btn-dark-blue btn-custom">More Info</a>
                    </div>
                    <div class="icon"><i class="fas fa-shopping-bag"></i></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-green text-center mb-4">
                    <div class="card-body">
                        <h5><?php echo htmlspecialchars($totalStok); ?></h5>
                        <p>Total Stok</p>
                        <a href="stok.php" class="btn btn-dark-green btn-custom">More Info</a>
                    </div>
                    <div class="icon"><i class="fas fa-check-square"></i></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-red text-center mb-4">
                    <div class="card-body">
                        <h5><?php echo htmlspecialchars($stokDalamProses); ?></h5>
                        <p>Stok Dalam Proses</p>
                        <a href="stok_dalam_proses.php" class="btn btn-dark-red btn-custom">More Info</a>
                    </div>
                    <div class="icon"><i class="fas fa-spinner"></i></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-yellow text-center mb-4">
                    <div class="card-body">
                        <h5><?php echo htmlspecialchars($stokBelumProses); ?></h5>
                        <p>Stok Belum Diproses</p>
                        <a href="stok_belum_proses.php" class="btn btn-dark-yellow btn-custom">More Info</a>
                    </div>
                    <div class="icon"><i class="fas fa-times-circle"></i></div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12"> 
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <i class="fas fa-phone-alt mr-2"></i>
                            <h5 class="card-title mb-0">Kontak Kami</h5>
                        </div>
                        <p class="card-text contact-text">
                            <strong>PT Ujung Berung (Office)</strong><br>
                            Jalan Dipatukur<br>
                            Bandung 40000<br>
                            (022) xxxxxxxx<br><br>
                            <strong>Eko Budi Setiawan</strong><br>
                            Product Development Manager<br>
                            xxx@xyy.com
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>